#'@rdname JRNMM_Splitting_Cpp
#'@title JRNMM_Splitting_Cpp
#'@description Simulate a trajectory from the N-Population JR-NMM
#' using Strang splitting
#'@return the trajectory Y1,...,YN
#'@export
JRNMM_Splitting_Cpp <- function(N, grid, h, startv, dm, meanVec, covMat, Theta, Rho, K){
  return(JRNMM_Splitting_Cpp_(N, grid, h, startv, dm, meanVec, covMat, Theta, Rho, K))
}
